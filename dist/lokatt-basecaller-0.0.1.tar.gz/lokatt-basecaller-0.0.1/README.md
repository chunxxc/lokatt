# lokatt
An open source HMM-DNN nanopore DNA basecaller
